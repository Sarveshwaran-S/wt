
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/studentDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// Schema
const Student = mongoose.model("Student", {
    name: String,
    email: String,
    age: Number,
    gender: String,
    department: String
});

// CREATE
app.post("/students", async (req, res) => {
    const student = await Student.create(req.body);
    res.json(student);
});

// READ
app.get("/students", async (req, res) => {
    const students = await Student.find();
    res.json(students);
});

// DELETE
app.delete("/students/:id", async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.json({ message: "Student Deleted" });
});

// SERVER
app.listen(5001, () => {
    console.log("Server running on port 5001");
});
