
var app = angular.module("myApp", []);

// SERVICE
app.service("StudentService", function($http) {

    this.getStudents = function() {
        return $http.get("http://localhost:5001/students");
    };

    this.addStudent = function(student) {
        return $http.post("http://localhost:5001/students", student);
    };

    this.deleteStudent = function(id) {
        return $http.delete("http://localhost:5001/students/" + id);
    };
});

// CONTROLLER
app.controller("myCtrl", function($scope, StudentService) {

    $scope.students = [];

    StudentService.getStudents().then(function(res) {
        $scope.students = res.data;
    });

    $scope.addStudent = function() {
        StudentService.addStudent({
            name: $scope.name,
            email: $scope.email,
            age: $scope.age,
            gender: $scope.gender,
            department: $scope.department
        }).then(function(res) {
            $scope.students.push(res.data);

            $scope.name = "";
            $scope.email = "";
            $scope.age = null;
            $scope.gender = "";
            $scope.department = "";
        });
    };

    $scope.deleteStudent = function(index) {
        var id = $scope.students[index]._id;

        StudentService.deleteStudent(id).then(function() {
            $scope.students.splice(index, 1);
        });
    };
});
