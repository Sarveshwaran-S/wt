
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pathlib import Path

driver = webdriver.Chrome()
wait = WebDriverWait(driver, 10)

try:
    # TEST 1: LOGIN
    driver.get(Path("login.html").resolve().as_uri())
    driver.maximize_window()

    driver.find_element(By.CSS_SELECTOR, '[ng-model="username"]').send_keys("admin")
    driver.find_element(By.CSS_SELECTOR, '[ng-model="password"]').send_keys("1234")
    driver.find_element(By.XPATH, '//button[text()="Login"]').click()

    wait.until(EC.url_contains("factory.html"))
    print("Login Test Passed")

    # TEST 2: STUDENT REGISTRATION
    driver.find_element(By.CSS_SELECTOR, '[ng-model="name"]').send_keys("Nabi")
    driver.find_element(By.CSS_SELECTOR, '[ng-model="email"]').send_keys("nabi@gmail.com")
    driver.find_element(By.CSS_SELECTOR, '[ng-model="age"]').send_keys("20")

    driver.find_element(By.CSS_SELECTOR, '[value="Female"]').click()

    Select(driver.find_element(By.CSS_SELECTOR, '[ng-model="department"]')).select_by_visible_text("IT")

    driver.find_element(By.XPATH, '//button[text()="Register"]').click()

    # TEST 3: VERIFY REGISTRATION
    wait.until(EC.presence_of_element_located(
        (By.CSS_SELECTOR, 'tr[ng-repeat]')
    ))

    rows = driver.find_elements(By.CSS_SELECTOR, 'tr[ng-repeat]')

    assert len(rows) == 1
    assert "Nabi" in rows[0].text
    print("Registration Test Passed")

    # TEST 4: DELETE STUDENT
    driver.find_element(By.XPATH, '//button[text()="Delete"]').click()

    wait.until(EC.invisibility_of_element_located(
        (By.CSS_SELECTOR, 'tr[ng-repeat]')
    ))

    print("Deletion Test Passed")

except Exception as e:
    print("Test Failed:", e)

finally:
    driver.quit()


install:
python3 -m pip install selenium

run:
python3 test.py
